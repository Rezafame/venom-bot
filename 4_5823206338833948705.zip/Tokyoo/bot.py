from colorama import Fore
from pyrogram import Client, filters, idle, errors
from pyrogram.types import *
from functools import wraps
from apscheduler.schedulers.asyncio import AsyncIOScheduler
import asyncio
import subprocess
import html
import zipfile
import pymysql
import shutil
import signal
import re
import os
from datetime import datetime
import random
import sys
#==================== Config =====================#
Admin = 8792087060  # عددی مالک
Token = "8910667370:AAHW6BwlPUAE0-PFx9Jpa6I_93RgkY2nDKI"  # توکن سلف ساز
API_ID = 26154106  # ایپی ایدی اکانت مالک
API_HASH = "86490b8b2b82b69a2eb012b9b20e4788"  # ایپی هش اکانت مالک
Channel_ID = "self_venom"  # ایدی چنل بدون @
grupself = "https://t.me/self_ven0m" # لینک گروه بدون همون که میدونی😔
ReportsChannel = "@Reports_selfali"  # کانال گزارشات انتقال الماس
Helper_ID = "@SaykkkXLXLXLXLX_bot"  # ایدی ربات هلپر بدون 
DBName = "piukhu_venom"  # اسم دیتابیس اصلی
DBUser = "root"  # یوزرنیم دیتابیس اصلی
DBPass = ""  # پسورد دیتابیس اصلی
HelperDBName = "piukhu_aseppn"  # اسم دیتابیس هلپر
HelperDBUser = "root"  # یوزرنیم دیتابیس هلپر
HelperDBPass = ""  # پسورد دیتابیس هلپر
CardNumber = "6219861859102385"  # شماره کارت برای فروش
CardName = "مهدی تاجی"  # اسم دارنده کارت
DIAMOND_PRICE = 30  # قیمت هر الماس به تومان (جدید: برای استفاده در همه جا)

#==================== Create =====================#
if not os.path.isdir("sessions"):
    os.mkdir("sessions")
if not os.path.isdir("selfs"):
    os.mkdir("selfs")

#===================== App =======================#
app = Client("Bot", api_id=API_ID, api_hash=API_HASH, bot_token=Token)
scheduler = AsyncIOScheduler()
scheduler.start()
active_games = {}
temp_Client = {}
temp_code = {}
lock = asyncio.Lock()

#===================== Database Functions ======================#
def get_data(query, params=None):
    try:
        connection = pymysql.connect(host="localhost", database=DBName, user=DBUser, password=DBPass, cursorclass=pymysql.cursors.DictCursor)
        db = connection.cursor()
        db.execute(query, params or ())
        return db.fetchone()
    except Exception as e:
        print(f"[DB][get_data] Error: {e}")
        return None
    finally:
        try: connection.close()
        except: pass

def get_datas(query):
    try:
        connection = pymysql.connect(host="localhost", database=DBName, user=DBUser, password=DBPass, cursorclass=pymysql.cursors.DictCursor)
        db = connection.cursor()
        db.execute(query)
        return db.fetchall()
    except Exception as e:
        print(f"[DB][get_datas] Error: {e}")
        return []
    finally:
        try: connection.close()
        except: pass

def update_data(query, params=None):
    try:
        connection = pymysql.connect(host="localhost", database=DBName, user=DBUser, password=DBPass, cursorclass=pymysql.cursors.DictCursor)
        db = connection.cursor()
        if params: db.execute(query, params)
        else: db.execute(query)
        connection.commit()
        return True
    except Exception as e:
        print(f"[DB][update_data] Error: {e}")
        return False
    finally:
        try: connection.close()
        except: pass

def helper_getdata(query):
    try:
        connection = pymysql.connect(host="localhost", database=HelperDBName, user=HelperDBUser, password=HelperDBPass, cursorclass=pymysql.cursors.DictCursor)
        db = connection.cursor()
        db.execute(query)
        return db.fetchone()
    except Exception as e:
        print(f"[DB][helper_getdata] Error: {e}")
        return None
    finally:
        try: connection.close()
        except: pass

def helper_updata(query):
    try:
        connection = pymysql.connect(host="localhost", database=HelperDBName, user=HelperDBUser, password=HelperDBPass, cursorclass=pymysql.cursors.DictCursor)
        db = connection.cursor()
        db.execute(query)
        connection.commit()
        return True
    except Exception as e:
        print(f"[DB][helper_updata] Error: {e}")
        return False
    finally:
        try: connection.close()
        except: pass

# ایجاد جداول
update_data("""
CREATE TABLE IF NOT EXISTS bot(
status varchar(10) DEFAULT 'ON'
) default charset=utf8mb4;
""")
update_data("""
CREATE TABLE IF NOT EXISTS user(
id bigint PRIMARY KEY,
step varchar(150) DEFAULT 'none',
phone varchar(150) DEFAULT NULL,
amount bigint DEFAULT '0',
expir bigint DEFAULT '0',
self varchar(50) DEFAULT 'inactive',
pid bigint DEFAULT NULL,
referrals bigint DEFAULT 0,
self_state varchar(20) DEFAULT 'running'
) default charset=utf8mb4;
""")
update_data("""
CREATE TABLE IF NOT EXISTS block(
id bigint PRIMARY KEY
) default charset=utf8mb4;
""")
helper_updata("""
CREATE TABLE IF NOT EXISTS ownerlist(
id bigint PRIMARY KEY
) default charset=utf8mb4;
""")
helper_updata("""
CREATE TABLE IF NOT EXISTS adminlist(
id bigint PRIMARY KEY
) default charset=utf8mb4;
""")

bot = get_data("SELECT * FROM bot")
if bot is None:
    update_data("INSERT INTO bot() VALUES()")

OwnerUser = helper_getdata(f"SELECT * FROM ownerlist WHERE id = '{Admin}' LIMIT 1")
if OwnerUser is None:
    helper_updata(f"INSERT INTO ownerlist(id) VALUES({Admin})")

AdminUser = helper_getdata(f"SELECT * FROM adminlist WHERE id = '{Admin}' LIMIT 1")
if AdminUser is None:
    helper_updata(f"INSERT INTO adminlist(id) VALUES({Admin})")

# ==================== توابع جدید مدیریت ادمین ==================== #
def is_admin(user_id):
    """بررسی ادمین بودن کاربر"""
    if user_id == Admin:
        return True
    admin = helper_getdata(f"SELECT * FROM adminlist WHERE id = '{user_id}' LIMIT 1")
    return admin is not None

def add_admin(user_id):
    """افزودن ادمین جدید"""
    if helper_getdata(f"SELECT * FROM adminlist WHERE id = '{user_id}' LIMIT 1") is None:
        helper_updata(f"INSERT INTO adminlist(id) VALUES({user_id})")
        return True
    return False

def delete_admin(user_id):
    """حذف ادمین"""
    if helper_getdata(f"SELECT * FROM adminlist WHERE id = '{user_id}' LIMIT 1") is not None:
        helper_updata(f"DELETE FROM adminlist WHERE id = '{user_id}' LIMIT 1")
        return True
    return False

def get_all_admins():
    """دریافت لیست تمام ادمین‌ها"""
    return helper_getdata("SELECT id FROM adminlist")

def ensure_user(user_id):
    user = get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
    if not user:
        update_data(f"INSERT INTO user(id) VALUES({user_id})")
    return get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")

#===================== Checker Decorator ======================#
async def check_user_membership(user_id):
    """بررسی عضویت کاربر در کانال"""
    try:
        await app.get_chat_member(Channel_ID, user_id)
        return True
    except errors.UserNotParticipant:
        return False
    except Exception:
        return False

def checker(func):
    @wraps(func)
    async def wrapper(c, m):
        if hasattr(m, 'chat') and m.chat.type in ["group", "supergroup", "channel"]:
            await func(c, m)
            return
            
        user_id = m.chat.id if hasattr(m, 'chat') else m.from_user.id
        block = get_data(f"SELECT * FROM block WHERE id = '{user_id}' LIMIT 1")
        if block is not None:
            return
        
        if hasattr(m, 'chat') and m.chat.type == "private":
            # بررسی آیا کاربر در حالت عضویت اجباری است؟
            user = get_data(f"SELECT step FROM user WHERE id = '{user_id}' LIMIT 1")
            if user and user["step"] == "waiting_join":
                # اگر کاربر در حال عضویت است، اجازه اجرای دستورات دیگر رو نده
                await func(c, m)
                return
            
            # بررسی عضویت کاربر
            is_member = await check_user_membership(user_id)
            if not is_member and user_id != Admin:
                # ارسال پیام عضویت اجباری
                join_keyboard = InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="𝗖𝗛𝗔𝗡𝗡𝗘𝗟", url=f"https://t.me/{Channel_ID}")
                        ],
                        [
                            InlineKeyboardButton(text="𝗚𝗥𝗢𝗨𝗣", url=f"https://t.me/Gp_selfali")
                        ],
                        [
                            InlineKeyboardButton(text="عضو شدم - فعالسازی ✅", callback_data="check_join")
                        ]
                    ]
                )
                
                join_message = f"""**برای استفاده از ربات لطفاً داخل کانال زیر عضو شوید:**"""
                
                # ذخیره پیام عضویت اجباری برای کاربر
                update_data(f"UPDATE user SET step = 'waiting_join' WHERE id = '{user_id}' LIMIT 1")
                
                try:
                    await app.send_message(
                        user_id, 
                        join_message, 
                        reply_markup=join_keyboard,
                        disable_web_page_preview=True
                    )
                except:
                    pass
                return
        
        bot = get_data("SELECT * FROM bot")
        if bot["status"] == "OFF" and user_id != Admin:
            await app.send_message(user_id, "**ربات خاموش میباشد!**")
            return
        await func(c, m)
    return wrapper

#===================== Diamond Scheduler ======================#
async def diamond_dec(user_id):
    user = get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
    if not user: return
        
    user_amount = user["amount"]
    if user_amount >= 2:
        user_upamount = user_amount - 2
        update_data(f"UPDATE user SET amount = '{user_upamount}' WHERE id = '{user_id}' LIMIT 1")
    else:
        job = scheduler.get_job(f"diamond_{user_id}")
        if job: scheduler.remove_job(f"diamond_{user_id}")
        
        if os.path.isdir(f"selfs/self-{user_id}"):
            pid = user.get("pid")
            if pid:
                try:
                    os.kill(pid, signal.SIGTERM)
                    await asyncio.sleep(2)
                except: pass
        
        update_data(f"UPDATE user SET self = 'inactive' WHERE id = '{user_id}' LIMIT 1")
        await app.send_message(user_id, "⛔ موجودی شما تمام شد و سلف خاموش شد.")

async def set_diamond_scheduler(user_id):
    job = scheduler.get_job(f"diamond_{user_id}")
    if not job:
        scheduler.add_job(diamond_dec, "interval", hours=1, args=[user_id], id=f"diamond_{user_id}")

#===================== Main Menu ======================#
Main = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton(text="فعالسازی سلف", callback_data="BuySub")
        ],
        [
            InlineKeyboardButton(text="مدیریت سلف", callback_data="BotManagement"),
            InlineKeyboardButton(text="حساب کاربری", callback_data="MyAccount")
        ],
        [
            InlineKeyboardButton(text="خرید الماس", callback_data="BuyDiamondAmount")
        ],
        [
            InlineKeyboardButton(text="پشتیبانی", url=grupself),
            InlineKeyboardButton(text="زیر مجموعه", callback_data="Referral")
        ]
    ]
)

# ==================== منوی مدیریت ادمین (جدید) ==================== #
AdminManagementMenu = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton(text="👤 افزودن ادمین", callback_data="add_admin")
        ],
        [
            InlineKeyboardButton(text="🗑 حذف ادمین", callback_data="remove_admin")
        ],
        [
            InlineKeyboardButton(text="📋 لیست ادمین", callback_data="list_admins")
        ],
        [
            InlineKeyboardButton(text="🔙 بازگشت", callback_data="BackToPanel")
        ]
    ]
)

#===================== سیستم عضویت اجباری جدید ======================#
@app.on_callback_query(filters.regex("^check_join$"))
async def check_join_callback(c, call):
    user_id = call.from_user.id
    
    # بررسی عضویت
    is_member = await check_user_membership(user_id)
    
    if is_member:
        # عضویت تایید شد
        try:
            await call.answer("✅ عضویت شما تایید شد.", show_alert=True)
        except:
            pass
        
        # حذف پیام عضویت اجباری
        try:
            await call.message.delete()
        except:
            pass
        
        # ارسال منوی اصلی
        await app.send_message(user_id, "🚀 به سلف‌ساز پیشرفته ونوم خوش آمدید ✨\n\n🪐 اینجا می‌توانید دستیار خودتان را داشته باشید و اکانتتان را ۲۴ ساعته آنلاین نگه دارید.\n\n👇جهت ادامه یکی از گزینه‌های زیر را انتخاب کنید:", reply_markup=Main)
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{user_id}' LIMIT 1")
        
        # ثبت کاربر در دیتابیس اگر وجود ندارد
        ensure_user(user_id)
    else:
        # هنوز عضو نشده
        try:
            await call.answer("❌ هنوز عضو نیستی!\nلطفاً اول در کانال عضو شوید سپس دکمه را بزنید.", show_alert=True)
        except:
            pass

#===================== قابلیت جدید: نمایش موجودی ======================#
@app.on_message(filters.text & filters.regex(r'^(موجودی)$') & (filters.private | filters.group))
@checker
async def show_balance(c, m):
    user_id = m.from_user.id
    user = ensure_user(user_id)
    amount = max(0, user['amount'])
    toman = amount * DIAMOND_PRICE
    balance_text = f"""
**📊 موجودی شما**

الماس 💎: {amount}
"""
    await m.reply(balance_text, reply_to_message_id=m.id)

#===================== قابلیت جدید: انتقال الماس ======================#
@app.on_message(filters.text & filters.regex(r'^انتقال الماس (\d+)(?:\s+(@\w+|\d+))?$') & (filters.private | filters.group))
@checker
async def transfer_coins(c, m):
    if not m.from_user:
        return
    user_id = m.from_user.id
    user = ensure_user(user_id)
    
    match = re.match(r'^انتقال الماس (\d+)(?:\s+(@\w+|\d+))?$', m.text)
    if not match:
        await m.reply("❌ فرمت دستور اشتباه است!\n\nمثال:\n- انتقال الماس 100 @username\n- انتقال الماس 100 123456789\n- انتقال الماس 100 (با ریپلای)", reply_to_message_id=m.id)
        return
    
    amount = int(match.group(1))
    target = match.group(2)
    
    # اگر ریپلای شده
    if m.reply_to_message:
        if not m.reply_to_message.from_user:
            await m.reply("❌ کاربر ریپلای‌شده معتبر نیست!", reply_to_message_id=m.id)
            return
        target_user_id = m.reply_to_message.from_user.id
    elif target:
        # اگر یوزرنیم یا آیدی عددی داده شده
        if target.startswith('@'):
            try:
                target_user = await app.get_users(target)
                target_user_id = target_user.id
            except Exception:
                await m.reply("❌ کاربر مورد نظر یافت نشد!", reply_to_message_id=m.id)
                return
        else:
            target_user_id = int(target)
    else:
        await m.reply("❌ باید روی کاربر ریپلای کنید یا یوزرنیم/آیدی عددی وارد کنید!", reply_to_message_id=m.id)
        return
    
    # بررسی اینکه کاربر به خودش انتقال ندهد
    if target_user_id == user_id:
        await m.reply("❌ نمی‌توانی به خودت انتقال بدهی.", reply_to_message_id=m.id)
        return
    
    # بررسی موجودی کاربر
    if user['amount'] < amount:
        await m.reply("❌ موجودی شما کافی نیست!", reply_to_message_id=m.id)
        return
    
    # بررسی وجود کاربر هدف
    target_user_data = ensure_user(target_user_id)
    
    # محاسبه مالیات (10%)
    tax = int(amount * 0.1)
    total_deducted = amount + tax
    
    # کسر از فرستنده (مبلغ + مالیات)
    new_sender_amount = max(0, user['amount'] - amount - tax)
    update_data(f"UPDATE user SET amount = '{new_sender_amount}' WHERE id = '{user_id}' LIMIT 1")
    
    # واریز به گیرنده (فقط مبلغ اصلی)
    new_receiver_amount = target_user_data['amount'] + amount
    update_data(f"UPDATE user SET amount = '{new_receiver_amount}' WHERE id = '{target_user_id}' LIMIT 1")
    
    # اطلاعات فرستنده
    sender_username = None
    sender_mention = None
    try:
        sender_user = await app.get_users(user_id)
        if sender_user.username:
            sender_username = f"@{sender_user.username}"
        else:
            sender_username = sender_user.first_name or f"کاربر {user_id}"
        
        # ایجاد منشن
        sender_mention = f"<a href='tg://user?id={user_id}'>{html.escape(sender_user.first_name or sender_user.username or f'کاربر {user_id}')}</a>"
    except:
        sender_username = str(user_id)
        sender_mention = str(user_id)
    
    # اطلاعات گیرنده برای منشن
    receiver_mention = None
    try:
        receiver_user = await app.get_users(target_user_id)
        receiver_mention = f"<a href='tg://user?id={target_user_id}'>{html.escape(receiver_user.first_name or receiver_user.username or f'کاربر {target_user_id}')}</a>"
    except:
        receiver_mention = str(target_user_id)
    
    # اطلاعات گیرنده برای نمایش ساده
    receiver_username = None
    try:
        receiver_user = await app.get_users(target_user_id)
        if receiver_user.username:
            receiver_username = f"@{receiver_user.username}"
        else:
            receiver_username = receiver_user.first_name or f"کاربر {target_user_id}"
    except:
        receiver_username = str(target_user_id)
    
    # رسید انتقال با فرمت جدید
    receipt_text = f"""
**✅ انتقال الماس انجام شد.**

👤 از: `{user_id}`
👥 به: `{target_user_id}`
💎 مبلغ انتقال (خالص): {amount}
🧾 مالیات: {tax}
📉 مجموع کسر از فرستنده: {total_deducted}
✨ موجودی جدید فرستنده: {new_sender_amount}
✨ موجودی جدید گیرنده: {new_receiver_amount}
"""
    
    await m.reply(receipt_text, reply_to_message_id=m.id)
    
    # اطلاع به گیرنده با فرمت جدید
    try:
        notification_text = f"""
**🎉 تبریک!**

💎 شما {amount} الماس دریافت کردید!
از طرف کاربر: {sender_mention}

**✨ موجودی جدید شما:** {new_receiver_amount}
"""
        await app.send_message(target_user_id, notification_text)
    except Exception as e:
        print(f"خطا در ارسال اطلاع به گیرنده: {e}")

#===================== قابلیت جدید: شرطبندی با بنر ======================#
@app.on_message(filters.text & filters.regex(r'^شرطبندی (\d+)$') & (filters.private | filters.group))
@checker
async def create_game(c, m):
    user_id = m.from_user.id
    user = ensure_user(user_id)
    
    match = re.match(r'^شرطبندی (\d+)$', m.text)
    if not match:
        await m.reply("❌ فرمت دستور اشتباه است!\nمثال: شرطبندی 100", reply_to_message_id=m.id)
        return
    
    bet_amount = int(match.group(1))
    
    if bet_amount < 20:
        await m.reply("❗️حداقل مبلغ شرطبندی 20 الماس است", reply_to_message_id=m.id)
        return
    
    if user['amount'] < bet_amount:
        await m.reply("❌ موجودی شما کافی نیست!", reply_to_message_id=m.id)
        return
    
    game_id = f"{m.chat.id}_{m.id}"
    active_games[game_id] = {
        'creator_id': user_id,
        'creator_username': f"@{m.from_user.username}" if m.from_user.username else m.from_user.first_name,
        'creator_mention': f"<a href='tg://user?id={user_id}'>{html.escape(m.from_user.first_name or m.from_user.username or f'کاربر {user_id}')}</a>",
        'bet_amount': bet_amount,
        'joined': False,
        'joiner_id': None,
        'message_id': None
    }
    
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✔️ پیوستن", callback_data=f"join_game_{game_id}"),
            InlineKeyboardButton("لغو ✘", callback_data=f"cancel_game_{game_id}")
        ]
    ])
    
    game_text = f"""
**◈ ━━━ 𝐕𝐈𝐏 𝐕𝐄𝐍𝐎𝐌 ━━━ ◈**
**𝐕𝐈𝐏 |** **شرطبندی :** {bet_amount} **الماس**
**𝐕𝐈𝐏 |** **سازنده:** {active_games[game_id]['creator_username']}
**◈ ━━━ 𝐕𝐈𝐏 𝐕𝐄𝐍𝐎𝐌 ━━━ ◈**
"""
    
    try:
        banner_channel = "lisjshs67logo"
        banner_msg_id = 60
        banner_msg = await app.get_messages(banner_channel, banner_msg_id)
        if banner_msg.photo:
            file_path = await app.download_media(banner_msg, file_name=f"banner_{game_id}.jpg")
            message = await app.send_photo(
                m.chat.id, 
                file_path, 
                caption=game_text, 
                reply_markup=keyboard, 
                reply_to_message_id=m.id
            )
            os.remove(file_path)
        else:
            message = await m.reply(game_text, reply_to_message_id=m.id, reply_markup=keyboard)
    except Exception as e:
        print(f"Error loading banner: {e}")
        message = await m.reply(game_text, reply_to_message_id=m.id, reply_markup=keyboard)
    
    active_games[game_id]['message_id'] = message.id

@app.on_callback_query(filters.regex(r'^join_game_'))
async def join_game_handler(c, call):
    game_id = call.data.replace('join_game_', '')
    
    if game_id not in active_games:
        await call.answer("❌ این شرطبندی منقضی شده است!", show_alert=True)
        return
    
    game = active_games[game_id]
    user_id = call.from_user.id
    
    if user_id == game['creator_id']:
        await call.answer("نمی‌توانی با شرط خودت شرطبندی کنی!", show_alert=True)
        return
    
    if game['joined']:
        await call.answer("❌ شرطبندی قبلاً شروع شده است!", show_alert=True)
        return
    
    user = ensure_user(user_id)
    if not user or user['amount'] < game['bet_amount']:
        await call.answer("❌ موجودی کافی نداری از قسمت خرید الماس شارژ کن", show_alert=True)
        return
    
    creator_data = ensure_user(game['creator_id'])
    if creator_data['amount'] < game['bet_amount']:
        await call.answer("❌ موجودی سازنده شرطبندی کافی نیست! شرطبندی لغو شد.", show_alert=True)
        del active_games[game_id]
        return
    
    # کم کردن مبلغ از هر دو شرطبندیکن
    new_creator_amount = max(0, creator_data['amount'] - game['bet_amount'])
    new_joiner_amount = max(0, user['amount'] - game['bet_amount'])
    
    update_data(f"UPDATE user SET amount = '{new_creator_amount}' WHERE id = '{game['creator_id']}' LIMIT 1")
    update_data(f"UPDATE user SET amount = '{new_joiner_amount}' WHERE id = '{user_id}' LIMIT 1")
    
    active_games[game_id]['joined'] = True
    active_games[game_id]['joiner_id'] = user_id
    active_games[game_id]['joiner_username'] = f"@{call.from_user.username}" if call.from_user.username else call.from_user.first_name
    active_games[game_id]['joiner_mention'] = f"<a href='tg://user?id={user_id}'>{html.escape(call.from_user.first_name or call.from_user.username or f'کاربر {user_id}')}</a>"
    
    if call.message.photo:
        await call.message.edit_caption("𝐕𝐈𝐏 𝐕𝐄𝐍𝐎𝐌 |...درحال اجرا")
    else:
        await call.message.edit_text("𝐕𝐈𝐏 𝐕𝐄𝐍𝐎𝐌 |...درحال اجرا")
    await asyncio.sleep(2)
    
    # انتخاب برنده تصادفی
    players = [game['creator_id'], user_id]
    winner_id = random.choice(players)
    loser_id = players[0] if players[1] == winner_id else players[1]
    
    total_pot = game['bet_amount'] * 2
    tax = int(total_pot * 0.06)
    prize = total_pot - tax
    
    # برنده جایزه را دریافت می‌کند
    winner_data = ensure_user(winner_id)
    new_winner_amount = winner_data['amount'] + prize
    update_data(f"UPDATE user SET amount = '{new_winner_amount}' WHERE id = '{winner_id}' LIMIT 1")
    
    # دریافت اطلاعات یوزرنیم/منشن برنده و بازنده
    winner_username = ""
    winner_mention = ""
    loser_username = ""
    loser_mention = ""
    
    try:
        winner_user = await app.get_users(winner_id)
        if winner_user.username:
            winner_username = f"@{winner_user.username}"
            winner_mention = f"@{winner_user.username}"
        else:
            winner_username = winner_user.first_name or f"کاربر {winner_id}"
            winner_mention = f"<a href='tg://user?id={winner_id}'>{html.escape(winner_user.first_name or f'کاربر {winner_id}')}</a>"
    except:
        winner_username = str(winner_id)
        winner_mention = str(winner_id)
    
    try:
        loser_user = await app.get_users(loser_id)
        if loser_user.username:
            loser_username = f"@{loser_user.username}"
            loser_mention = f"@{loser_user.username}"
        else:
            loser_username = loser_user.first_name or f"کاربر {loser_id}"
            loser_mention = f"<a href='tg://user?id={loser_id}'>{html.escape(loser_user.first_name or f'کاربر {loser_id}')}</a>"
    except:
        loser_username = str(loser_id)
        loser_mention = str(loser_id)
    
    # ساخت متن نتیجه با فرمت درخواستی
    result_text = f"""
**◈ ━━━ 𝐕𝐈𝐏 𝐕𝐄𝐍𝐎𝐌 ━━━ ◈**
**𝐕𝐈𝐏 |** **نتیجه شرطبندی :**
**𝐕𝐈𝐏 |** **برنده :** {winner_mention} (`{winner_id}`)
**𝐕𝐈𝐏 |** **بازنده :** {loser_mention} (`{loser_id}`)
**𝐕𝐈𝐏 |** **جایزه:** {prize} **الماس**
**𝐕𝐈𝐏 |** **مالیات:** {tax} **الماس**
**◈ ━━━ 𝐕𝐈𝐏 𝐕𝐄𝐍𝐎𝐌 ━━━ ◈**
"""
    
    if call.message.photo:
        await call.message.edit_caption(result_text)
    else:
        await call.message.edit_text(result_text)
    
    del active_games[game_id]

@app.on_callback_query(filters.regex(r'^cancel_game_'))
async def cancel_game_handler(c, call):
    game_id = call.data.replace('cancel_game_', '')
    
    if game_id not in active_games:
        await call.answer("❌ این شرطبندی منقضی شده است!", show_alert=True)
        return
    
    game = active_games[game_id]
    
    if call.from_user.id != game['creator_id']:
        await call.answer("❌ فقط سازنده شرطبندی میتواند لغو کند!", show_alert=True)
        return
    
    if call.message.photo:
        await call.message.edit_caption("شرطبندی توسط سازنده لغو شد.")
    else:
        await call.message.edit_text("شرطبندی توسط سازنده لغو شد.")
    del active_games[game_id]

#===================== Main Handlers ======================#
@app.on_message(filters.private, group=-1)
async def update(c, m):
    user = get_data(f"SELECT * FROM user WHERE id = '{m.chat.id}' LIMIT 1")
    if user is None:
        update_data(f"INSERT INTO user(id) VALUES({m.chat.id})")

@app.on_message(filters.private&filters.command("start"))
@checker
async def update(c, m):
    user_id = m.chat.id
    bot_info = await app.get_me()
    
    if len(m.command) > 1:
        ref = m.command[1]
        if ref.startswith('ref_'):
            try:
                ref_id = int(ref[4:])
                user = get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
                if user and user['pid'] is None:
                    update_data(f"UPDATE user SET pid = {ref_id} WHERE id = '{user_id}' LIMIT 1")
                    referrer = get_data(f"SELECT * FROM user WHERE id = '{ref_id}' LIMIT 1")
                    if referrer:
                        new_referrer_amount = referrer['amount'] + 20
                        update_data(f"UPDATE user SET amount = {new_referrer_amount} WHERE id = '{ref_id}' LIMIT 1")
                        new_referrals = referrer['referrals'] + 1
                        update_data(f"UPDATE user SET referrals = {new_referrals} WHERE id = '{ref_id}' LIMIT 1")
                        await app.send_message(ref_id, "🎁 یک کاربر با لینک دعوت شما وارد شد.\n20 الماس به موجودیت اضافه شد.")
            except ValueError:
                pass

    await app.send_message(m.chat.id, "🚀 به سلف‌ساز پیشرفته ونوم خوش آمدید ✨\n\n🪐 اینجا می‌توانید دستیار خودتان را داشته باشید و اکانتتان را ۲۴ ساعته آنلاین نگه دارید.\n\n👇جهت ادامه یکی از گزینه‌های زیر را انتخاب کنید:", reply_markup=Main)
    update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
    async with lock:
        if m.chat.id in temp_Client:
            del temp_Client[m.chat.id]
        if m.chat.id in temp_code:
            del temp_code[m.chat.id]

#===================== Callback Handlers ======================#
@app.on_callback_query()
@checker
async def call(c, call):
    global temp_Client, temp_code
    user = get_data(f"SELECT * FROM user WHERE id = '{call.from_user.id}' LIMIT 1")
    if not user:
        await app.answer_callback_query(call.id, "خطا در دریافت اطلاعات کاربر!", show_alert=True)
        return
        
    phone_number = user["phone"]
    amount = user["amount"]
    chat_id = call.from_user.id
    m_id = call.message.id
    data = call.data

    # ========== مدیریت ادمین (قابلیت جدید) ========== #
    if data == "add_admin":
        if not is_admin(call.from_user.id):
            await call.answer("❌ شما دسترسی ندارید!", show_alert=True)
            return
        await call.message.edit_text(
            "**👤 افزودن ادمین جدید**\n\nلطفاً آیدی عددی کاربر مورد نظر را ارسال کنید:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت", callback_data="BackToPanel")]])
        )
        update_data(f"UPDATE user SET step = 'waiting_admin_id_add' WHERE id = '{chat_id}' LIMIT 1")
        
    elif data == "remove_admin":
        if not is_admin(call.from_user.id):
            await call.answer("❌ شما دسترسی ندارید!", show_alert=True)
            return
        await call.message.edit_text(
            "**🗑 حذف ادمین**\n\nلطفاً آیدی عددی ادمین مورد نظر را ارسال کنید:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت", callback_data="BackToPanel")]])
        )
        update_data(f"UPDATE user SET step = 'waiting_admin_id_remove' WHERE id = '{chat_id}' LIMIT 1")
        
    elif data == "list_admins":
        if not is_admin(call.from_user.id):
            await call.answer("❌ شما دسترسی ندارید!", show_alert=True)
            return
        admins = get_datas("SELECT id FROM adminlist")
        if admins:
            admin_list = "**📋 لیست ادمین‌های ربات:**\n\n"
            for i, admin in enumerate(admins, 1):
                admin_id = admin['id']
                try:
                    user = await app.get_users(admin_id)
                    name = user.first_name or user.username or "بدون نام"
                    admin_list += f"{i}. `{admin_id}` | {name}\n"
                except:
                    admin_list += f"{i}. `{admin_id}` | (کاربر یافت نشد)\n"
        else:
            admin_list = "**📋 لیست ادمین‌ها خالی است!**"
        await call.message.edit_text(
            admin_list,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت", callback_data="BackToPanel")]])
        )
        
    elif data == "BackToPanel":
        if not is_admin(call.from_user.id):
            await call.answer("❌ شما دسترسی ندارید!", show_alert=True)
            return
        await call.message.edit_text(
            "**👥 پنل مدیریت ادمین‌ها**\n\nیکی از گزینه‌های زیر را انتخاب کنید:",
            reply_markup=AdminManagementMenu
        )
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{chat_id}' LIMIT 1")
        
    # ========== ادامه کالبک‌های اصلی ========== #
    if data == "BuySub" or data == "Back2":
        # نمایش منوی فعالسازی مانند سورس دوم
        await app.edit_message_text(chat_id, m_id, """**فعالسازی سلف

مرحله ۱ - شارژ الماس
ابتدا از بخش «خرید الماس» حساب خودتون رو به مقدار لازم شارژ کنید. 💎

مرحله ۲ - دریافت کد
دکمه «فعال‌سازی» رو بزنید تا کد مخصوص تلگرام براتون ارسال بشه. 📥

مرحله ۳ - وارد کردن کد
کد دریافتی رو به صورت عددی و پشت‌سرهم (مثال: 35901) در بات وارد کنید.
اگر اکانتتان رمز دو مرحله دارد، بات از شما می‌خواهد و آن را هم وارد می‌کنید. 🔤

مرحله ۴ - فعال‌سازی
با تأیید نهایی، سلف بات با موفقیت روی اکانت شما فعال می‌شود. ✅

💰 محاسبه مصرف الماس:

🤖 نرخ فعالسازی سلف: ۳۲ الماس
⏰ هر ۱ ساعت فعالیت بات: ‌۲ الماس
📆 مصرف ماهانه تقریبی: ۱,۴۴۰ الماس**""", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="فعالسازی سلف", callback_data="Login-32")
                ],
                [
                    InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                ]
            ]
        ))
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
        async with lock:
            if chat_id in temp_Client:
                del temp_Client[chat_id]
            if chat_id in temp_code:
                del temp_code[chat_id]

    elif data.split("-")[0] == "Login":
        diamond_count = data.split("-")[1]
        if int(amount) >= int(diamond_count):
            # درخواست شماره تلفن دستی مانند سورس دوم
            await app.delete_messages(chat_id, m_id)
            await app.send_message(chat_id, "لطفاً شماره تلفن خود را ارسال کنید:\n\nمثال: +989123456789")
            update_data(f"UPDATE user SET step = 'contact-{diamond_count}' WHERE id = '{call.from_user.id}' LIMIT 1")
        else:
            await app.edit_message_text(chat_id, m_id, "الماس کافی ندارید، لطفاً الماس خود را شارژ کنید.", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="خرید الماس", callback_data="BuyDiamond")
                    ],
                    [
                        InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back2")
                    ]
                ]
            ))
            update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data == "MyAccount":
        username = f"@{call.from_user.username}" if call.from_user.username else "وجود ندارد"
        user_info = f"""
حساب کاربری شما:
🆔 آیدی عددی: `{chat_id}`
🔗 یوزرنیم: `{username if username != "وجود ندارد" else "ندارد"}`
💎 الماس: `{amount}`
📱 شماره: `{phone_number if phone_number else "ثبت نشده"}` {'(✅)' if phone_number else ''}
🧩 وضعیت سلف: `{'ON' if user['self'] == 'active' else 'OFF'}`
"""
        await app.edit_message_text(chat_id, m_id, user_info, reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                ]
            ]
        ))
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")

    # این بخش مربوط به دکمه‌های صفحه کلید شماره شیشه‌ای هست که قبلاً داشتیم
    elif data.startswith("phone_"):
        if user["step"] != 'activation_code_keyboard':
            return
        
        async with lock:
            code_input = temp_code.get(chat_id, "")
        
        if data == "phone_0":
            new_code = code_input + "0"
        elif data == "phone_1":
            new_code = code_input + "1"
        elif data == "phone_2":
            new_code = code_input + "2"
        elif data == "phone_3":
            new_code = code_input + "3"
        elif data == "phone_4":
            new_code = code_input + "4"
        elif data == "phone_5":
            new_code = code_input + "5"
        elif data == "phone_6":
            new_code = code_input + "6"
        elif data == "phone_7":
            new_code = code_input + "7"
        elif data == "phone_8":
            new_code = code_input + "8"
        elif data == "phone_9":
            new_code = code_input + "9"
        elif data == "phone_delete":
            new_code = code_input[:-1] if len(code_input) > 0 else ""
        elif data == "phone_submit":
            async with lock:
                code_input = temp_code.get(chat_id, "")
            
            if len(code_input) == 5:
                code = code_input
                mess = await app.send_message(chat_id, "در حال پردازش...")
                try:
                    async with lock:
                        await temp_Client[chat_id]["client"].sign_in(temp_Client[chat_id]["number"], temp_Client[chat_id]["response"].phone_code_hash, code)
                        await temp_Client[chat_id]["client"].disconnect()
                        del temp_Client[chat_id]
                    
                    async with lock:
                        if chat_id in temp_code:
                            del temp_code[chat_id]
                    
                    mess = await app.edit_message_text(chat_id, mess.id, "لاگین با موفقیت انجام شد")
                    mess = await app.edit_message_text(chat_id, mess.id, "در حال فعالسازی سلف...\n(ممکن است چند لحظه طول بکشد)")
                    
                    if not os.path.isdir(f"selfs/self-{chat_id}"):
                        os.mkdir(f"selfs/self-{chat_id}")
                        with zipfile.ZipFile("source/Self.zip", "r") as extract:
                            extract.extractall(f"selfs/self-{chat_id}")
                    
                    process = subprocess.Popen(
                        [sys.executable, "self.py", str(chat_id), str(API_ID), API_HASH, Helper_ID],
                        cwd=f"selfs/self-{chat_id}"
                    )
                    await asyncio.sleep(10)
                    
                    if process.poll() is None:
                        await app.edit_message_text(chat_id, mess.id, "سلف با موفقیت برای اکانت شما فعال شد\n`پنل`", reply_markup=InlineKeyboardMarkup(
                            [
                                [
                                    InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                                ]
                            ]
                        ))
                        
                        upamount = int(amount) - 32
                        update_data(f"UPDATE user SET amount = '{upamount}' WHERE id = '{chat_id}' LIMIT 1")
                        update_data(f"UPDATE user SET self = 'active' WHERE id = '{chat_id}' LIMIT 1")
                        update_data(f"UPDATE user SET pid = '{process.pid}' WHERE id = '{chat_id}' LIMIT 1")
                        update_data(f"UPDATE user SET step = 'none' WHERE id = '{chat_id}' LIMIT 1")
                        add_admin(chat_id)
                        await set_diamond_scheduler(chat_id)
                        
                        await app.send_message(Admin, f"#گزارش_فعالسازی\n\nآیدی کاربر: `{chat_id}`\nشماره کاربر: {phone_number}\nالماس مصرفی: 32 الماس")
                    else:
                        await app.edit_message_text(chat_id, mess.id, "در فعالسازی سلف مشکلی رخ داد! هیچ الماس‌ای کسر نشد", reply_markup=InlineKeyboardMarkup(
                            [
                                [
                                    InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                                ]
                            ]
                        ))
                        update_data(f"UPDATE user SET step = 'none' WHERE id = '{chat_id}' LIMIT 1")
                        
                except errors.SessionPasswordNeeded:
                    await app.edit_message_text(chat_id, mess.id, "رمز دو مرحله‌ای را وارد کنید:", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                            ]
                        ]
                    ))
                    update_data(f"UPDATE user SET step = 'activation_password' WHERE id = '{chat_id}' LIMIT 1")
                    async with lock:
                        if chat_id in temp_code:
                            del temp_code[chat_id]
                            
                except Exception as e:
                    print(f"Error: {e}")
                    async with lock:
                        if chat_id in temp_code:
                            del temp_code[chat_id]
                    
            else:
                await app.answer_callback_query(call.id, "کد کامل نیست! 5 رقم وارد کنید.", show_alert=True)
            return
        
        # آپدیت temp_code
        async with lock:
            temp_code[chat_id] = new_code
        
        # نمایش کد آپدیت شده
        if len(new_code) == 0:
            text = """✅ کد ورود ارسال شد.

کد را با دکمه‌های زیر وارد کن:"""
        else:
            text = f"""کد وارد شده:
`{new_code}`"""
        
        # صفحه کلید شیشه‌ای
        keyboard = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("𝟏", callback_data="phone_1"),
                    InlineKeyboardButton("𝟐", callback_data="phone_2"), 
                    InlineKeyboardButton("𝟑", callback_data="phone_3")
                ],
                [
                    InlineKeyboardButton("𝟒", callback_data="phone_4"),
                    InlineKeyboardButton("𝟓", callback_data="phone_5"),
                    InlineKeyboardButton("𝟔", callback_data="phone_6")
                ],
                [
                    InlineKeyboardButton("𝟕", callback_data="phone_7"),
                    InlineKeyboardButton("𝟖", callback_data="phone_8"), 
                    InlineKeyboardButton("𝟗", callback_data="phone_9")
                ],
                [
                    InlineKeyboardButton("⌫", callback_data="phone_delete"),
                    InlineKeyboardButton("𝟎", callback_data="phone_0"),
                    InlineKeyboardButton("✅ تأیید", callback_data="phone_submit")
                ],
                [
                    InlineKeyboardButton("❌ لغو", callback_data="Back")
                ]
            ]
        )
        await app.edit_message_text(chat_id, m_id, text, reply_markup=keyboard)

    elif data == "BuyDiamond" or data == "Back3":
        await app.edit_message_text(chat_id, m_id, f"موجودی الماس شما: {amount}\nیکی از گزینه های زیر را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="خرید الماس", callback_data="BuyDiamondAmount")
                ],
                [
                    InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                ]
            ]
        ))
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data == "BuyDiamondAmount":
        await app.edit_message_text(chat_id, m_id, "🛒 خرید الماس\nمیزان الماس مورد نظر خود را برای شارژ حساب وارد کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                ]
            ]
        ))
        update_data(f"UPDATE user SET step = 'buydiamond1' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data.split("-")[0] == "AcceptAmount":
        user_id = int(data.split("-")[1])
        count = int(data.split("-")[2])
        user_amount = get_data(f"SELECT amount FROM user WHERE id = '{user_id}' LIMIT 1")
        user_upamount = int(user_amount["amount"]) + int(count)
        update_data(f"UPDATE user SET amount = '{user_upamount}' WHERE id = '{user_id}' LIMIT 1")
        await app.edit_message_text(Admin, m_id, f"تایید انجام شد\nمبلغ {count} الماس به حساب کاربر [ {user_id} ] انتقال یافت\nموجودی جدید کاربر: {user_upamount} الماس")
        await app.send_message(user_id, f"🎉 پرداخت شما تایید شد!\nمقدار {count} الماس به حسابت اضافه شد. ممنون از خریدتان.")

    elif data.split("-")[0] == "RejectAmount":
        user_id = int(data.split("-")[1])
        await app.edit_message_text(Admin, m_id, "درخواست کاربر مورد نظر برای افزایش موجودی رد شد")
        await app.send_message(user_id, "درخواست شما برای افزایش موجودی رد شد")

    elif data == "Referral":
        referrals_query = get_datas(f"SELECT COUNT(id) as count FROM user WHERE pid = {chat_id}")
        referrals_count = referrals_query[0]['count'] if referrals_query else 0
        bot_info = await app.get_me()
        referral_link = f"https://t.me/{bot_info.username}?start=ref_{chat_id}"
        referral_info = f"""
💎 با دعوت دوستان خود
20 الماس دریافت کنید!
👥 کل دعوتی‌ها: {referrals_count}
💎 دعوت‌های پاداش‌دار: {referrals_count}
🔗 لینک دعوت:
`{referral_link}`
"""
        await app.edit_message_text(chat_id, m_id, referral_info, reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                ]
            ]
        ))
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data == "BotManagement":
        if user["self"] == "active":
            await app.edit_message_text(chat_id, m_id, "منوی کنترل سلف:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="🟢 روشن کردن سلف", callback_data="TurnOnSelf"),
                        InlineKeyboardButton(text="🔴 خاموش کردن سلف", callback_data="TurnOffSelf")
                    ],
                    [
                        InlineKeyboardButton(text="🗑 حذف سلف", callback_data="DeleteSelf")
                    ],
                    [
                        InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                    ]
                ]
            ))
        else:
            await app.answer_callback_query(call.id, text="سلف برای اکانت شما فعال نیست!!", show_alert=True)

    elif data == "TurnOnSelf":
        if user["self"] == "active":
            pid = user.get("pid")
            if pid:
                try:
                    os.kill(pid, 0)
                except OSError:
                    if os.path.isdir(f"selfs/self-{chat_id}"):
                        process = subprocess.Popen(
                            [sys.executable, "self.py", str(chat_id), str(API_ID), API_HASH, Helper_ID],
                            cwd=f"selfs/self-{chat_id}"
                        )
                        await asyncio.sleep(5)
                        if process.poll() is None:
                            await app.answer_callback_query(call.id, text="سلف روشن شد!", show_alert=True)
                        else:
                            await app.answer_callback_query(call.id, text="خطا در روشن کردن سلف!", show_alert=True)
                    else:
                        await app.answer_callback_query(call.id, text="پوشه سلف یافت نشد!", show_alert=True)
                else:
                    await app.answer_callback_query(call.id, text="سلف از قبل روشن است!", show_alert=True)
            else:
                if os.path.isdir(f"selfs/self-{chat_id}"):
                    process = subprocess.Popen(
                        [sys.executable, "self.py", str(chat_id), str(API_ID), API_HASH, Helper_ID],
                        cwd=f"selfs/self-{chat_id}"
                    )
                    update_data(f"UPDATE user SET pid = '{process.pid}' WHERE id = '{chat_id}' LIMIT 1")
                    await asyncio.sleep(5)
                    if process.poll() is None:
                        await app.answer_callback_query(call.id, text="سلف روشن شد!", show_alert=True)
                    else:
                        await app.answer_callback_query(call.id, text="خطا در روشن کردن سلف!", show_alert=True)
                else:
                    await app.answer_callback_query(call.id, text="پوشه سلف یافت نشد!", show_alert=True)
        else:
            await app.answer_callback_query(call.id, text="سلف برای اکانت شما فعال نیست!!", show_alert=True)

    elif data == "TurnOffSelf":
        if user["self"] == "active":
            pid = user.get("pid")
            if pid:
                try:
                    os.kill(pid, signal.SIGTERM)
                    await asyncio.sleep(2)
                    await app.answer_callback_query(call.id, text="سلف خاموش شد!", show_alert=True)
                except ProcessLookupError:
                    await app.answer_callback_query(call.id, text="سلف از قبل خاموش است!", show_alert=True)
                except Exception as e:
                    await app.answer_callback_query(call.id, text=f"خطا در خاموش کردن سلف: {e}", show_alert=True)
            else:
                await app.answer_callback_query(call.id, text="سلف از قبل خاموش است!", show_alert=True)
        else:
            await app.answer_callback_query(call.id, text="سلف برای اکانت شما فعال نیست!!", show_alert=True)

    elif data == "DeleteSelf":
        if user["self"] == "active":
            pid = user.get("pid")
            if pid:
                try:
                    os.kill(pid, signal.SIGTERM)
                    await asyncio.sleep(2)
                except: pass
            
            if os.path.isdir(f"selfs/self-{chat_id}"):
                try:
                    shutil.rmtree(f"selfs/self-{chat_id}")
                except: pass
            
            if os.path.isfile(f"sessions/{chat_id}.session"):
                try:
                    async with Client(f"sessions/{chat_id}", api_id=API_ID, api_hash=API_HASH) as user_client:
                        await user_client.log_out()
                except: pass
                
                try:
                    if os.path.isfile(f"sessions/{chat_id}.session"):
                        os.remove(f"sessions/{chat_id}.session")
                except: pass
            
            if os.path.isfile(f"sessions/{chat_id}.session-journal"):
                try:
                    os.remove(f"sessions/{chat_id}.session-journal")
                except: pass
            
            update_data(f"UPDATE user SET self = 'inactive' WHERE id = '{chat_id}' LIMIT 1")
            update_data(f"UPDATE user SET pid = NULL WHERE id = '{chat_id}' LIMIT 1")
            delete_admin(chat_id)
            
            await app.answer_callback_query(call.id, text="سلف حذف شد!", show_alert=True)
            await app.send_message(chat_id, "🚀 به سلف‌ساز پیشرفته ونوم خوش آمدید ✨\n\n🪐 اینجا می‌توانید دستیار خودتان را داشته باشید و اکانتتان را ۲۴ ساعته آنلاین نگه دارید.\n\n👇جهت ادامه یکی از گزینه‌های زیر را انتخاب کنید:", reply_markup=Main)
        else:
            await app.answer_callback_query(call.id, text="سلف برای اکانت شما فعال نیست!!", show_alert=True)

    elif data == "BuyGuide":
        await app.edit_message_text(chat_id, m_id, """**راهنمای خرید 

𝟏 ـ شما ابتدا الماس خود را از قسمت خرید الماس شارژ میکنید💎

𝟐  ـ سپس با زدن روی دکمه فعالسازی کد تلگرام برای شما ارسال میشود.. 📥

𝟑 ـ کد را به این صورت وارد میکنید 3.5.9.0.1 ، در صورت داشتن رمز دو مرحله آن را از شما میخواهد و آن را وارد میکنید.. 🔤

𝟒 ـ سلف روی اکانت شما با موفقیت فعال میشود .

𝟓 - مصرف الماس : 
🔻 هر ساعت = ۲ الماس
💎 نرخ ماهانه: ۱۴۴۰ الماس**""", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                ]
            ]
        ))
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data == "Support":
        await app.edit_message_text(chat_id, m_id, "پیام خود را ارسال کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                ]
            ]
        ))
        update_data(f"UPDATE user SET step = 'support' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data.split("-")[0] == "Reply":
        exit = data.split("-")[1]
        getuser = await app.get_users(exit)
        await app.send_message(Admin, f"پیام خود را برای کاربر [ {html.escape(getuser.first_name)} ] ارسال کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="صفحه اصلی", callback_data="Back"),
                    InlineKeyboardButton(text="پنل مدیریت", callback_data="Panel")
                ]
            ]
        ))
        update_data(f"UPDATE user SET step = 'ureply-{exit}' WHERE id = '{Admin}' LIMIT 1")

    elif data.split("-")[0] == "Block":
        exit = data.split("-")[1]
        getuser = await app.get_users(exit)
        block = get_data(f"SELECT * FROM block WHERE id = '{exit}' LIMIT 1")
        if block is None:
            await app.send_message(exit, "کاربر محترم شما به دلیل نقض قوانین از ربات مسدود شدید")
            await app.send_message(Admin, f"کاربر [ {html.escape(getuser.first_name)} ] از ربات بلاک شد")
            update_data(f"INSERT INTO block(id) VALUES({exit})")
        else:
            await app.send_message(Admin, f"کاربر [ {html.escape(getuser.first_name)} ] از قبل بلاک است")

    elif data == "Back":
        try:
            await app.edit_message_text(
                chat_id,
                m_id,
                "🚀 به سلف‌ساز پیشرفته ونوم خوش آمدید ✨\n\n🪐 اینجا می‌توانید دستیار خودتان را داشته باشید و اکانتتان را ۲۴ ساعته آنلاین نگه دارید.\n\n👇جهت ادامه یکی از گزینه‌های زیر را انتخاب کنید:",
                reply_markup=Main
            )
            update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
            async with lock:
                if chat_id in temp_Client:
                    del temp_Client[chat_id]
                if chat_id in temp_code:
                    del temp_code[chat_id]
        except errors.MessageNotModified:
            update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
            async with lock:
                if chat_id in temp_Client:
                    del temp_Client[chat_id]
                if chat_id in temp_code:
                    del temp_code[chat_id]
            await app.answer_callback_query(call.id, text="به منوی اصلی بازگشتید!", show_alert=True)
        except Exception as e:
            await app.answer_callback_query(call.id, text="خطایی رخ داد! لطفاً دوباره تلاش کنید.", show_alert=True)

    elif data == "text":
        await app.answer_callback_query(call.id, text="این دکمه نمایشی است", show_alert=True)

#===================== Message Handlers ======================#
@app.on_message(filters.private)
@checker
async def update(c, m):
    global temp_Client, temp_code
    user = get_data(f"SELECT * FROM user WHERE id = '{m.chat.id}' LIMIT 1")
    if not user:
        return
        
    username = f"@{m.from_user.username}" if m.from_user.username else "وجود ندارد"
    phone_number = user["phone"]
    amount = user["amount"]
    chat_id = m.chat.id
    text = m.text
    m_id = m.id

    # ========== پردازش افزودن و حذف ادمین ========== #
    if user["step"] == 'waiting_admin_id_add' and is_admin(chat_id):
        if text.isdigit():
            target_id = int(text)
            if target_id == chat_id:
                await m.reply("❌ شما خودتان از قبل ادمین هستید!")
            elif add_admin(target_id):
                await m.reply(f"✅ کاربر `{target_id}` با موفقیت به ادمین‌ها اضافه شد.")
                try:
                    await app.send_message(target_id, "🎉 شما به عنوان ادمین ربات انتخاب شدید!\nاز این پس میتوانید از پنل مدیریت استفاده کنید.")
                except:
                    pass
            else:
                await m.reply(f"⚠️ کاربر `{target_id}` از قبل ادمین است!")
        else:
            await m.reply("❌ لطفاً فقط آیدی عددی ارسال کنید!")
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{chat_id}' LIMIT 1")
        
    elif user["step"] == 'waiting_admin_id_remove' and is_admin(chat_id):
        if text.isdigit():
            target_id = int(text)
            if target_id == Admin:
                await m.reply("❌ نمیتوانید مالک اصلی را حذف کنید!")
            elif delete_admin(target_id):
                await m.reply(f"✅ کاربر `{target_id}` از لیست ادمین‌ها حذف شد.")
                try:
                    await app.send_message(target_id, "⚠️ دسترسی مدیریت شما از ربات حذف شد.")
                except:
                    pass
            else:
                await m.reply(f"⚠️ کاربر `{target_id}` ادمین نیست!")
        else:
            await m.reply("❌ لطفاً فقط آیدی عددی ارسال کنید!")
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{chat_id}' LIMIT 1")

    # سیستم دریافت شماره دستی (مثل سورس دوم)
    elif user["step"] and user["step"].split("-")[0] == "contact":
        diamond_count = user["step"].split("-")[1]
        
        if text and re.match(r'^\+?[0-9]{10,15}$', text.replace(" ", "").replace("-", "")):
            phone_number = text.strip()
            if not phone_number.startswith("+"):
                phone_number = f"+{phone_number}"
            
            # ثبت شماره
            update_data(f"UPDATE user SET phone = '{phone_number}' WHERE id = '{m.chat.id}' LIMIT 1")
            
            # شروع فرآیند لاگین
            mess = await app.send_message(chat_id, "در حال پردازش...")
            async with lock:
                if chat_id not in temp_Client:
                    temp_Client[chat_id] = {}
                temp_Client[chat_id]["client"] = Client(f"sessions/{chat_id}", api_id=API_ID, api_hash=API_HASH, device_model="center-self", system_version="Linux")
                temp_Client[chat_id]["number"] = phone_number
                await temp_Client[chat_id]["client"].connect()
            
            try:
                await app.edit_message_text(chat_id, mess.id, "کد تایید 5 رقمی را با فرمت زیر ارسال کنید:\n1.2.3.4.5")
                async with lock:
                    temp_Client[chat_id]["response"] = await temp_Client[chat_id]["client"].send_code(temp_Client[chat_id]["number"])
                update_data(f"UPDATE user SET step = 'login1-{diamond_count}' WHERE id = '{m.chat.id}' LIMIT 1")

            except errors.PhoneNumberInvalid:
                await app.edit_message_text(chat_id, mess.id, "این شماره نامعتبر است!", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back2")
                        ]
                    ]
                ))
                update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                async with lock:
                    await temp_Client[chat_id]["client"].disconnect()
                    if chat_id in temp_Client:
                        del temp_Client[chat_id]
                if os.path.isfile(f"sessions/{chat_id}.session"):
                    try:
                        os.remove(f"sessions/{chat_id}.session")
                    except: pass

            except Exception as e:
                print(f"Error in contact: {e}")
                async with lock:
                    await temp_Client[chat_id]["client"].disconnect()
                    if chat_id in temp_Client:
                        del temp_Client[chat_id]
                if os.path.isfile(f"sessions/{chat_id}.session"):
                    try:
                        os.remove(f"sessions/{chat_id}.session")
                    except: pass
        else:
            await app.send_message(chat_id, "شماره تلفن نامعتبر است! لطفاً شماره را با فرمت صحیح ارسال کنید:\n\nمثال: +989123456789")

    elif user["step"].split("-")[0] == "login1":
        if re.match(r'^\d\.\d\.\d\.\d\.\d$', text):
            code = ''.join(re.findall(r'\d', text))
            diamond_count = user["step"].split("-")[1]
            mess = await app.send_message(chat_id, "در حال پردازش...")
            try:
                async with lock:
                    await temp_Client[chat_id]["client"].sign_in(temp_Client[chat_id]["number"], temp_Client[chat_id]["response"].phone_code_hash, code)
                    await temp_Client[chat_id]["client"].disconnect()
                    if chat_id in temp_Client:
                        del temp_Client[chat_id]
                mess = await app.edit_message_text(chat_id, mess.id, "لاگین با موفقیت انجام شد")
                mess = await app.edit_message_text(chat_id, mess.id, "در حال فعالسازی سلف...\n(ممکن است چند لحظه طول بکشد)")
                
                if not os.path.isdir(f"selfs/self-{m.chat.id}"):
                    os.mkdir(f"selfs/self-{m.chat.id}")
                    with zipfile.ZipFile("source/Self.zip", "r") as extract:
                        extract.extractall(f"selfs/self-{m.chat.id}")
                
                process = subprocess.Popen(
                    [sys.executable, "self.py", str(chat_id), str(API_ID), API_HASH, Helper_ID],
                    cwd=f"selfs/self-{chat_id}"
                )
                await asyncio.sleep(10)
                
                if process.poll() is None:
                    await app.edit_message_text(chat_id, mess.id, "سلف با موفقیت برای اکانت شما فعال شد", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                            ]
                        ]
                    ))
                    
                    upamount = int(amount) - int(diamond_count)
                    update_data(f"UPDATE user SET amount = '{upamount}' WHERE id = '{m.chat.id}' LIMIT 1")
                    update_data(f"UPDATE user SET self = 'active' WHERE id = '{m.chat.id}' LIMIT 1")
                    update_data(f"UPDATE user SET pid = '{process.pid}' WHERE id = '{m.chat.id}' LIMIT 1")
                    update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                    add_admin(m.chat.id)
                    await set_diamond_scheduler(m.chat.id)
                    
                    await app.send_message(Admin, f"#گزارش_فعالسازی\n\nآیدی کاربر: `{m.chat.id}`\nشماره کاربر: {phone_number}\nالماس مصرفی: {diamond_count} الماس")
                else:
                    await app.edit_message_text(chat_id, mess.id, "در فعالسازی سلف مشکلی رخ داد! هیچ الماس‌ای کسر نشد", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                            ]
                        ]
                    ))
                    update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                    
            except errors.SessionPasswordNeeded:
                await app.edit_message_text(chat_id, mess.id, "رمز دو مرحله‌ای را وارد کنید:", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back2")
                        ]
                    ]
                ))
                update_data(f"UPDATE user SET step = 'login2-{diamond_count}' WHERE id = '{m.chat.id}' LIMIT 1")
                
            except Exception as e:
                print(f"Error in login1: {e}")
                async with lock:
                    await temp_Client[chat_id]["client"].disconnect()
                    if chat_id in temp_Client:
                        del temp_Client[chat_id]

    elif user["step"].split("-")[0] == "login2":
        password = text.strip()
        diamond_count = user["step"].split("-")[1]
        mess = await app.send_message(chat_id, "در حال پردازش...")
        try:
            async with lock:
                await temp_Client[chat_id]["client"].check_password(password)
                await temp_Client[chat_id]["client"].disconnect()
                if chat_id in temp_Client:
                    del temp_Client[chat_id]
            
            mess = await app.edit_message_text(chat_id, mess.id, "لاگین با موفقیت انجام شد")
            mess = await app.edit_message_text(chat_id, mess.id, "در حال فعالسازی سلف...\n(ممکن است چند لحظه طول بکشد)")
            
            if not os.path.isdir(f"selfs/self-{m.chat.id}"):
                os.mkdir(f"selfs/self-{m.chat.id}")
                with zipfile.ZipFile("source/Self.zip", "r") as extract:
                    extract.extractall(f"selfs/self-{m.chat.id}")
            
            process = subprocess.Popen(
                [sys.executable, "self.py", str(chat_id), str(API_ID), API_HASH, Helper_ID],
                cwd=f"selfs/self-{chat_id}"
            )
            await asyncio.sleep(10)
            
            if process.poll() is None:
                await app.edit_message_text(chat_id, mess.id, "سلف با موفقیت برای اکانت شما فعال شد", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                        ]
                    ]
                ))
                
                upamount = int(amount) - int(diamond_count)
                update_data(f"UPDATE user SET amount = '{upamount}' WHERE id = '{m.chat.id}' LIMIT 1")
                update_data(f"UPDATE user SET self = 'active' WHERE id = '{m.chat.id}' LIMIT 1")
                update_data(f"UPDATE user SET pid = '{process.pid}' WHERE id = '{m.chat.id}' LIMIT 1")
                update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                add_admin(m.chat.id)
                await set_diamond_scheduler(m.chat.id)
                
                await app.send_message(Admin, f"#گزارش_فعالسازی\n\nآیدی کاربر: `{m.chat.id}`\nشماره کاربر: {phone_number}\nالماس مصرفی: {diamond_count} الماس")
            else:
                await app.edit_message_text(chat_id, mess.id, "در فعالسازی سلف مشکلی رخ داد! هیچ الماس‌ای کسر نشد", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                        ]
                    ]
                ))
                update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                
        except errors.BadRequest:
            await app.edit_message_text(chat_id, mess.id, "رمز نادرست است!\nرمز را وارد کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back2")
                    ]
                ]
            ))
        except Exception as e:
            print(f"Error in login2: {e}")

    # این بخش مربوط به سیستم قدیمی دریافت شماره با دکمه هست که هنوز وجود داره
    elif user["step"] == 'activation_phone':
        if m.contact:
            # شماره از طریق دکمه ارسال شده
            phone_number = m.contact.phone_number
            if not phone_number.startswith('+'):
                phone_number = '+' + phone_number
            update_data(f"UPDATE user SET phone = '{phone_number}' WHERE id = '{chat_id}' LIMIT 1")
            
            mess = await app.send_message(chat_id, "در حال پردازش...")
            async with lock:
                if chat_id not in temp_Client:
                    temp_Client[chat_id] = {}
                temp_Client[chat_id]["client"] = Client(f"sessions/{chat_id}", api_id=API_ID, api_hash=API_HASH, device_model="center-self", system_version="Linux")
                temp_Client[chat_id]["number"] = phone_number
                await temp_Client[chat_id]["client"].connect()
            
            try:
                # صفحه کلید شیشه‌ای برای وارد کردن کد
                await app.edit_message_text(chat_id, mess.id, """✅ کد ورود ارسال شد.

کد را با دکمه‌های زیر وارد کن:""", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton("𝟏", callback_data="phone_1"),
                            InlineKeyboardButton("𝟐", callback_data="phone_2"), 
                            InlineKeyboardButton("𝟑", callback_data="phone_3")
                        ],
                        [
                            InlineKeyboardButton("𝟒", callback_data="phone_4"),
                            InlineKeyboardButton("𝟓", callback_data="phone_5"),
                            InlineKeyboardButton("𝟔", callback_data="phone_6")
                        ],
                        [
                            InlineKeyboardButton("𝟕", callback_data="phone_7"),
                            InlineKeyboardButton("𝟖", callback_data="phone_8"), 
                            InlineKeyboardButton("𝟗", callback_data="phone_9")
                        ],
                        [
                            InlineKeyboardButton("⌫", callback_data="phone_delete"),
                            InlineKeyboardButton("𝟎", callback_data="phone_0"),
                            InlineKeyboardButton("✅ تأیید", callback_data="phone_submit")
                        ],
                        [
                            InlineKeyboardButton("❌ لغو", callback_data="Back")
                        ]
                    ]
                ))
                
                async with lock:
                    temp_Client[chat_id]["response"] = await temp_Client[chat_id]["client"].send_code(temp_Client[chat_id]["number"])
                    temp_code[chat_id] = ""  # مقداردهی اولیه کد ورودی
                
                update_data(f"UPDATE user SET step = 'activation_code_keyboard' WHERE id = '{chat_id}' LIMIT 1")
                
                # حذف کیبورد شماره
                await app.send_message(chat_id, "✅ شماره دریافت شد. لطفا کد 5 رقمی را با دکمه‌های بالا وارد کنید.", reply_markup=ReplyKeyboardRemove())

            except errors.PhoneNumberInvalid:
                await app.edit_message_text(chat_id, mess.id, "این شماره نامعتبر است!", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                        ]
                    ]
                ))
                update_data(f"UPDATE user SET step = 'none' WHERE id = '{chat_id}' LIMIT 1")
                async with lock:
                    await temp_Client[chat_id]["client"].disconnect()
                    del temp_Client[chat_id]
                    if chat_id in temp_code:
                        del temp_code[chat_id]
                
                if os.path.isfile(f"sessions/{chat_id}.session"):
                    try:
                        os.remove(f"sessions/{chat_id}.session")
                    except: pass

            except Exception as e:
                print(f"Error in activation_phone: {e}")
                async with lock:
                    await temp_Client[chat_id]["client"].disconnect()
                    del temp_Client[chat_id]
                    if chat_id in temp_code:
                        del temp_code[chat_id]
                
                if os.path.isfile(f"sessions/{chat_id}.session"):
                    try:
                        os.remove(f"sessions/{chat_id}.session")
                    except: pass
                    
        elif re.match(r'^\+\d{10,15}$', text):
            # شماره دستی وارد شده
            phone_number = text
            update_data(f"UPDATE user SET phone = '{phone_number}' WHERE id = '{chat_id}' LIMIT 1")
            
            mess = await app.send_message(chat_id, "در حال پردازش...")
            async with lock:
                if chat_id not in temp_Client:
                    temp_Client[chat_id] = {}
                temp_Client[chat_id]["client"] = Client(f"sessions/{chat_id}", api_id=API_ID, api_hash=API_HASH, device_model="center-self", system_version="Linux")
                temp_Client[chat_id]["number"] = phone_number
                await temp_Client[chat_id]["client"].connect()
            
            try:
                # صفحه کلید شیشه‌ای برای وارد کردن کد
                await app.edit_message_text(chat_id, mess.id, """✅ کد ورود ارسال شد.

کد را با دکمه‌های زیر وارد کن:""", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton("𝟏", callback_data="phone_1"),
                            InlineKeyboardButton("𝟐", callback_data="phone_2"), 
                            InlineKeyboardButton("𝟑", callback_data="phone_3")
                        ],
                        [
                            InlineKeyboardButton("𝟒", callback_data="phone_4"),
                            InlineKeyboardButton("𝟓", callback_data="phone_5"),
                            InlineKeyboardButton("𝟔", callback_data="phone_6")
                        ],
                        [
                            InlineKeyboardButton("𝟕", callback_data="phone_7"),
                            InlineKeyboardButton("𝟖", callback_data="phone_8"), 
                            InlineKeyboardButton("𝟗", callback_data="phone_9")
                        ],
                        [
                            InlineKeyboardButton("⌫", callback_data="phone_delete"),
                            InlineKeyboardButton("𝟎", callback_data="phone_0"),
                            InlineKeyboardButton("✅ تأیید", callback_data="phone_submit")
                        ],
                        [
                            InlineKeyboardButton("❌ لغو", callback_data="Back")
                        ]
                    ]
                ))
                
                async with lock:
                    temp_Client[chat_id]["response"] = await temp_Client[chat_id]["client"].send_code(temp_Client[chat_id]["number"])
                    temp_code[chat_id] = ""  # مقداردهی اولیه کد ورودی
                
                update_data(f"UPDATE user SET step = 'activation_code_keyboard' WHERE id = '{chat_id}' LIMIT 1")
                # حذف کیبورد شماره اگر وجود دارد
                try:
                    await app.send_message(chat_id, "✅ شماره دریافت شد. لطفا کد 5 رقمی را با دکمه‌های بالا وارد کنید.", reply_markup=ReplyKeyboardRemove())
                except:
                    pass

            except Exception as e:
                print(f"Error in activation_phone (manual): {e}")
                async with lock:
                    await temp_Client[chat_id]["client"].disconnect()
                    del temp_Client[chat_id]
                    if chat_id in temp_code:
                        del temp_code[chat_id]
                
                if os.path.isfile(f"sessions/{chat_id}.session"):
                    try:
                        os.remove(f"sessions/{chat_id}.session")
                    except: pass
        else:
            await app.send_message(chat_id, "فرمت شماره نامعتبر است! لطفا دکمه 'ارسال شماره' را بزنید یا شماره را با فرمت +989123456789 ارسال کنید.")

    # پردازش رمز دو مرحله‌ای (برای سیستم قدیمی)
    elif user["step"] == 'activation_password':
        password = text.strip()
        mess = await app.send_message(chat_id, "در حال پردازش...")
        try:
            async with lock:
                await temp_Client[chat_id]["client"].check_password(password)
                await temp_Client[chat_id]["client"].disconnect()
                del temp_Client[chat_id]
                if chat_id in temp_code:
                    del temp_code[chat_id]
            
            mess = await app.edit_message_text(chat_id, mess.id, "لاگین با موفقیت انجام شد")
            mess = await app.edit_message_text(chat_id, mess.id, "در حال فعالسازی سلف...")
            
            if not os.path.isdir(f"selfs/self-{chat_id}"):
                os.mkdir(f"selfs/self-{chat_id}")
                with zipfile.ZipFile("source/Self.zip", "r") as extract:
                    extract.extractall(f"selfs/self-{chat_id}")
            
            process = subprocess.Popen(
                [sys.executable, "self.py", str(chat_id), str(API_ID), API_HASH, Helper_ID],
                cwd=f"selfs/self-{chat_id}"
            )
            await asyncio.sleep(10)
            
            if process.poll() is None:
                await app.edit_message_text(chat_id, mess.id, "سلف با موفقیت برای اکانت شما فعال شد", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                        ]
                    ]
                ))
                
                upamount = int(amount) - 32
                update_data(f"UPDATE user SET amount = '{upamount}' WHERE id = '{chat_id}' LIMIT 1")
                update_data(f"UPDATE user SET self = 'active' WHERE id = '{chat_id}' LIMIT 1")
                update_data(f"UPDATE user SET pid = '{process.pid}' WHERE id = '{chat_id}' LIMIT 1")
                update_data(f"UPDATE user SET step = 'none' WHERE id = '{chat_id}' LIMIT 1")
                add_admin(chat_id)
                await set_diamond_scheduler(chat_id)
                
                await app.send_message(Admin, f"#گزارش_فعالسازی\n\nآیدی کاربر: `{chat_id}`\nشماره کاربر: {phone_number}\nالماس مصرفی: 32 الماس")
            else:
                await app.edit_message_text(chat_id, mess.id, "در فعالسازی سلف مشکلی رخ داد! هیچ الماس‌ای کسر نشد", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                        ]
                    ]
                ))
                update_data(f"UPDATE user SET step = 'none' WHERE id = '{chat_id}' LIMIT 1")
                
                if os.path.isfile(f"sessions/{chat_id}.session"):
                    try:
                        os.remove(f"sessions/{chat_id}.session")
                    except: pass
                    
        except errors.BadRequest:
            await app.edit_message_text(chat_id, mess.id, "رمز نادرست است!\nرمز را وارد کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back")
                    ]
                ]
            ))
        except Exception as e:
            print(f"Error in activation_password: {e}")
            async with lock:
                await temp_Client[chat_id]["client"].disconnect()
                del temp_Client[chat_id]
                if chat_id in temp_code:
                    del temp_code[chat_id]
            
            if os.path.isfile(f"sessions/{chat_id}.session"):
                try:
                    os.remove(f"sessions/{chat_id}.session")
                except: pass

    elif user["step"] == "buydiamond1":
        if text.isdigit():
            count = text.strip()
            diamond_price = int(count) * DIAMOND_PRICE
            await app.send_message(chat_id, f"فاکتور خرید الماس به تعداد {count} الماس ایجاد شد\n\nشماره کارت: `{CardNumber}`\nبه نام {CardName}\nمبلغ قابل پرداخت: {diamond_price} تومان\n\nبعد از پرداخت رسید تراکنش را در همین قسمت ارسال کنید", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="⏪ بازگشت", callback_data="Back3")
                    ]
                ]
            ))
            update_data(f"UPDATE user SET step = 'buydiamond2-{count}' WHERE id = '{m.chat.id}' LIMIT 1")
        else:
            await app.send_message(chat_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif user["step"].split("-")[0] == "buydiamond2":
        if m.photo:
            count = int(user["step"].split("-")[1])
            mess = await app.forward_messages(from_chat_id=chat_id, chat_id=Admin, message_ids=m_id)
            await app.send_message(Admin, f"""
مدیر گرامی درخواست خرید الماس جدید دارید

نام کاربر: {html.escape(m.chat.first_name)}
آیدی کاربر: `{m.chat.id}`
یوزرنیم کاربر: {username}
تعداد الماس درخواستی کاربر: {count} الماس
مبلغ قابل پرداخت: {int(count) * DIAMOND_PRICE} تومان
""", reply_to_message_id=mess.id, reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton("تایید", callback_data=f"AcceptAmount-{chat_id}-{count}"),
                        InlineKeyboardButton("رد کردن", callback_data=f"RejectAmount-{chat_id}")
                    ]
                ]
            ))
            await app.send_message(chat_id, "✅ فیش دریافت شد. پس از بررسی نتیجه اعلام می‌شود.", reply_to_message_id=m_id)
            update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
        else:
            await app.send_message(chat_id, "ورودی نامعتبر! فقط ارسال عکس مجاز است")

    elif user["step"] == "support":
        mess = await app.forward_messages(from_chat_id=chat_id, chat_id=Admin, message_ids=m_id)
        await app.send_message(Admin, f"""
مدیر گرامی پیام ارسال شده جدید دارید

نام کاربر: {html.escape(m.chat.first_name)}
آیدی کاربر: `{m.chat.id}`
یوزرنیم کاربر: {username}
""", reply_to_message_id=mess.id, reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("پاسخ", callback_data=f"Reply-{chat_id}"),
                    InlineKeyboardButton("بلاک", callback_data=f"Block-{chat_id}")
                ]
            ]
        ))
        await app.send_message(chat_id, "پیام شما ارسال شد و در اسرع وقت به آن پاسخ داده خواهد شد", reply_to_message_id=m_id)

    elif user["step"].split("-")[0] == "ureply":
        exit = user["step"].split("-")[1]
        mess = await app.copy_message(from_chat_id=Admin, chat_id=exit, message_id=m_id)
        await app.send_message(exit, "کاربر گرامی پیام ارسال شده جدید از پشتیبانی دارید", reply_to_message_id=mess.id)
        await app.send_message(Admin, "پیام شما ارسال شد پیام دیگری ارسال یا روی یکی از گزینه های زیر کلیک کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="صفحه اصلی", callback_data="Back"),
                    InlineKeyboardButton(text="پنل مدیریت", callback_data="Panel")
                ]
            ]
        ))

#===================== پنل مدیریت جدید (مثل سورس دوم) ======================#
Panel = ReplyKeyboardMarkup(
    [
        [
            ("آمار 📊")
        ],
        [
            ("ارسال همگانی ✉️"),
            ("فوروارد همگانی ✉️")
        ],
        [
            ("الماس همگانی 💎"),  # قابلیت جدید
            ("کسر همگانی ➖")      # قابلیت جدید
        ],
        [
            ("مدیریت ادمین 👥")    # قابلیت جدید
        ],
        [
            ("آنبلاک کاربر ✅️"),
            ("بلاک کاربر 🚫")
        ],
        [
            ("افزایش الماس ➕"),
            ("کسر الماس ➖")
        ],
        [
            ("افزودن زمان اشتراک ➕"),
            ("کسر زمان اشتراک ➖")
        ],
        [
            ("فعال کردن سلف 🔵"),
            ("غیرفعال کردن سلف 🔴")
        ],
        [
            ("روشن کردن ربات 🔵"),
            ("خاموش کردن ربات 🔴")
        ],
        [
            ("صفحه اصلی 🏠")
        ]
    ], resize_keyboard=True
)

AdminBack = ReplyKeyboardMarkup(
    [
        [
            ("⏪ بازگشت")
        ]
    ], resize_keyboard=True
)

@app.on_message(filters.private&filters.user(Admin)&filters.command("panel"), group=1)
async def update(c, m):
    await app.send_message(Admin, "**💎 پنل مدیریت سلف بات 💎**\n\nمدیر گرامی به پنل مدیریت خوش آمدید!", reply_markup=Panel)
    update_data(f"UPDATE user SET step = 'none' WHERE id = '{Admin}' LIMIT 1")
    async with lock:
        if Admin in temp_Client:
            del temp_Client[Admin]
        if Admin in temp_code:
            del temp_code[Admin]

@app.on_callback_query(filters.user(Admin), group=-1)
async def call(c, call):
    data = call.data
    m_id = call.message.id
    if data == "Panel":
        await app.send_message(Admin, "**💎 پنل مدیریت سلف بات 💎**\n\nمدیر گرامی به پنل مدیریت خوش آمدید!", reply_markup=Panel)
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{Admin}' LIMIT 1")
        async with lock:
            if Admin in temp_Client:
                del temp_Client[Admin]
            if Admin in temp_code:
                del temp_code[Admin]

# هندلر پنل مدیریت
@app.on_message(filters.private&filters.user(Admin), group=1)
async def update(c, m):
    bot = get_data("SELECT * FROM bot")
    user = get_data(f"SELECT * FROM user WHERE id = '{Admin}' LIMIT 1")
    text = m.text
    m_id = m.id

    if text == "⏪ بازگشت":
        await app.send_message(Admin, "**💎 پنل مدیریت سلف بات 💎**\n\nمدیر گرامی به پنل مدیریت خوش آمدید!", reply_markup=Panel)
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{Admin}' LIMIT 1")
        async with lock:
            if Admin in temp_Client:
                del temp_Client[Admin]
            if Admin in temp_code:
                del temp_code[Admin]

    elif text == "آمار 📊":
        mess = await app.send_message(Admin, "در حال دریافت اطلاعات...")
        botinfo = await app.get_me()
        allusers = get_datas("SELECT COUNT(id) as count FROM user")
        allblocks = get_datas("SELECT COUNT(id) as count FROM block")
        active_users = get_datas("SELECT COUNT(id) as count FROM user WHERE self = 'active'")
        total_diamonds = get_datas("SELECT SUM(amount) as total FROM user WHERE amount > 0")
        total_admins = get_datas("SELECT COUNT(id) as count FROM adminlist")
        
        await app.edit_message_text(Admin, mess.id, f"""
📈 **آمار کامل سیستم:**

👥 تعداد کاربران: `{allusers[0]['count'] if allusers else 0} نفر`
🔴 کاربران بلاک شده: `{allblocks[0]['count'] if allblocks else 0} نفر`
🟢 کاربران فعال (سلف): `{active_users[0]['count'] if active_users else 0} نفر`
💎 کل الماس موجود: `{total_diamonds[0]['total'] if total_diamonds and total_diamonds[0]['total'] else 0} الماس`
👮‍♂️ تعداد ادمین‌ها: `{total_admins[0]['count'] if total_admins else 0} نفر`
""")
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{Admin}' LIMIT 1")

    elif text == "ارسال همگانی ✉️":
        await app.send_message(Admin, "📤 **ارسال همگانی پیام**\n\nلطفاً پیام خود را ارسال کنید:", reply_markup=AdminBack)
        update_data(f"UPDATE user SET step = 'sendall' WHERE id = '{Admin}' LIMIT 1")

    elif user["step"] == "sendall":
        mess = await app.send_message(Admin, "⏳ **در حال ارسال همگانی...**\n\nلطفاً کمی صبر کنید")
        users = get_datas(f"SELECT id FROM user")
        success = 0
        fail = 0
        for user_data in users:
            try:
                await app.copy_message(from_chat_id=Admin, chat_id=user_data['id'], message_id=m_id)
                success += 1
                await asyncio.sleep(0.1)
            except Exception as e:
                fail += 1
                print(f"Error sending to {user_data['id']}: {e}")
        await app.edit_message_text(Admin, mess.id, f"✅ **ارسال همگانی تکمیل شد**\n\n📊 آمار ارسال:\n├ ارسال موفق: {success} کاربر\n└ ارسال ناموفق: {fail} کاربر")

    elif text == "فوروارد همگانی ✉️":
        await app.send_message(Admin, "📤 **فوروارد همگانی پیام**\n\nلطفاً پیام خود را ارسال کنید:", reply_markup=AdminBack)
        update_data(f"UPDATE user SET step = 'forall' WHERE id = '{Admin}' LIMIT 1")

    elif user["step"] == "forall":
        mess = await app.send_message(Admin, "⏳ **در حال فوروارد همگانی...**\n\nلطفاً کمی صبر کنید")
        users = get_datas(f"SELECT id FROM user")
        success = 0
        fail = 0
        for user_data in users:
            try:
                await app.forward_messages(from_chat_id=Admin, chat_id=user_data['id'], message_ids=m_id)
                success += 1
                await asyncio.sleep(0.1)
            except Exception as e:
                fail += 1
                print(f"Error forwarding to {user_data['id']}: {e}")
        await app.edit_message_text(Admin, mess.id, f"✅ **فوروارد همگانی تکمیل شد**\n\n📊 آمار فوروارد:\n├ فوروارد موفق: {success} کاربر\n└ فوروارد ناموفق: {fail} کاربر")

    # ========== قابلیت الماس همگانی ========== #
    elif text == "الماس همگانی 💎":
        await app.send_message(Admin, "💎 **ارسال الماس همگانی**\n\nمقدار الماس برای **افزودن** به تمام کاربران را وارد کنید:", reply_markup=AdminBack)
        update_data(f"UPDATE user SET step = 'mass_diamond_add' WHERE id = '{Admin}' LIMIT 1")

    elif user["step"] == "mass_diamond_add":
        if text.isdigit():
            diamond_amount = int(text.strip())
            if diamond_amount <= 0:
                await app.send_message(Admin, "❌ مقدار الماس باید بیشتر از صفر باشد!")
                return
            
            status_msg = await app.send_message(Admin, f"⏳ **در حال افزودن {diamond_amount} الماس به تمام کاربران...**")
            
            users = get_datas("SELECT id, amount FROM user")
            total = len(users)
            success = 0
            failed = 0
            
            for user_data in users:
                try:
                    user_id = user_data['id']
                    current_amount = user_data['amount'] or 0
                    new_amount = current_amount + diamond_amount
                    update_data(f"UPDATE user SET amount = '{new_amount}' WHERE id = '{user_id}' LIMIT 1")
                    success += 1
                    
                    # ارسال نوتیفیکیشن به کاربر
                    try:
                        notify_text = f"""
**🎁 الماس همگانی از طرف مدیریت ❤️‍🔥**

💎 **مقدار اضافه شده:** `{diamond_amount}` الماس
📊 **موجودی قبلی:** `{current_amount}` الماس
✨ **موجودی جدید:** `{new_amount}` الماس

🕒 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
                        await app.send_message(user_id, notify_text)
                    except:
                        pass
                    
                    await asyncio.sleep(0.05)
                except Exception as e:
                    print(f"Error adding diamonds to {user_id}: {e}")
                    failed += 1
            
            report_text = f"""
✅ **ارسال الماس همگانی با موفقیت انجام شد!**

📊 **آمار عملیات:**
━━━━━━━━━━━━━━━━━━
👥 **کل کاربران:** `{total}`
✅ **موفق:** `{success}`
❌ **ناموفق:** `{failed}`

💎 **جزئیات:**
━━━━━━━━━━━━━━━━━━
🔹 **مقدار به ازای هر کاربر:** `{diamond_amount}`
🔸 **الماس کل ارسالی:** `{diamond_amount * success}`
━━━━━━━━━━━━━━━━━━
🕒 **زمان:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
            await status_msg.edit_text(report_text)
            update_data(f"UPDATE user SET step = 'none' WHERE id = '{Admin}' LIMIT 1")
        else:
            await app.send_message(Admin, "❌ مقدار باید عدد باشد!")

    # ========== قابلیت کسر همگانی ========== #
    elif text == "کسر همگانی ➖":
        await app.send_message(Admin, "➖ **کسر همگانی الماس**\n\n⚠️ **توجه:** این عملیات از موجودی تمام کاربران کسر میکند!\n\nمقدار الماس برای **کسر** از تمام کاربران را وارد کنید:", reply_markup=AdminBack)
        update_data(f"UPDATE user SET step = 'mass_diamond_deduct' WHERE id = '{Admin}' LIMIT 1")

    elif user["step"] == "mass_diamond_deduct":
        if text.isdigit():
            diamond_amount = int(text.strip())
            if diamond_amount <= 0:
                await app.send_message(Admin, "❌ مقدار الماس باید بیشتر از صفر باشد!")
                return
            
            status_msg = await app.send_message(Admin, f"⏳ **در حال کسر {diamond_amount} الماس از تمام کاربران...**")
            
            users = get_datas("SELECT id, amount FROM user")
            total = len(users)
            success = 0
            failed = 0
            insufficient = 0
            
            for user_data in users:
                try:
                    user_id = user_data['id']
                    current_amount = user_data['amount'] or 0
                    
                    if current_amount >= diamond_amount:
                        new_amount = current_amount - diamond_amount
                        update_data(f"UPDATE user SET amount = '{new_amount}' WHERE id = '{user_id}' LIMIT 1")
                        success += 1
                        
                        # ارسال نوتیفیکیشن به کاربر
                        try:
                            notify_text = f"""
**📉 کسر همگانی الماس از طرف مدیریت**

🔻 **مقدار کسر شده:** `{diamond_amount}` الماس
📊 **موجودی قبلی:** `{current_amount}` الماس
💎 **موجودی جدید:** `{new_amount}` الماس

🕒 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
                            await app.send_message(user_id, notify_text)
                        except:
                            pass
                    else:
                        insufficient += 1
                    
                    await asyncio.sleep(0.05)
                except Exception as e:
                    print(f"Error deducting diamonds from {user_id}: {e}")
                    failed += 1
            
            report_text = f"""
✅ **کسر همگانی الماس با موفقیت انجام شد!**

📊 **آمار عملیات:**
━━━━━━━━━━━━━━━━━━
👥 **کل کاربران:** `{total}`
✅ **کسر موفق:** `{success}`
⚠️ **موجودی ناکافی:** `{insufficient}`
❌ **خطا:** `{failed}`

💎 **جزئیات:**
━━━━━━━━━━━━━━━━━━
🔹 **مقدار کسر به ازای هر کاربر:** `{diamond_amount}`
🔸 **الماس کل کسر شده:** `{diamond_amount * success}`
━━━━━━━━━━━━━━━━━━
🕒 **زمان:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
            await status_msg.edit_text(report_text)
            update_data(f"UPDATE user SET step = 'none' WHERE id = '{Admin}' LIMIT 1")
        else:
            await app.send_message(Admin, "❌ مقدار باید عدد باشد!")

    # ========== مدیریت ادمین در پنل ========== #
    elif text == "مدیریت ادمین 👥":
        await app.send_message(Admin, "**👥 پنل مدیریت ادمین‌ها**\n\nیکی از گزینه‌های زیر را انتخاب کنید:", reply_markup=AdminManagementMenu)
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{Admin}' LIMIT 1")

    elif text == "بلاک کاربر 🚫":
        await app.send_message(Admin, "🚫 **بلاک کردن کاربر**\n\nآیدی عددی کاربر را ارسال کنید:", reply_markup=AdminBack)
        update_data(f"UPDATE user SET step = 'userblock' WHERE id = '{Admin}' LIMIT 1")

    elif user["step"] == "userblock":
        if text.isdigit():
            user_id = int(text.strip())
            if get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1") is not None:
                block = get_data(f"SELECT * FROM block WHERE id = '{user_id}' LIMIT 1")
                if block is None:
                    await app.send_message(user_id, "کاربر محترم شما به دلیل نقض قوانین از ربات مسدود شدید")
                    await app.send_message(Admin, f"کاربر [ {user_id} ] از ربات بلاک شد")
                    update_data(f"INSERT INTO block(id) VALUES({user_id})")
                else:
                    await app.send_message(Admin, "این کاربر از قبل بلاک است")
            else:
                await app.send_message(Admin, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(Admin, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif text == "آنبلاک کاربر ✅️":
        await app.send_message(Admin, "✅ **آنبلاک کردن کاربر**\n\nآیدی عددی کاربر را ارسال کنید:", reply_markup=AdminBack)
        update_data(f"UPDATE user SET step = 'userunblock' WHERE id = '{Admin}' LIMIT 1")

    elif user["step"] == "userunblock":
        if text.isdigit():
            user_id = int(text.strip())
            if get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1") is not None:
                block = get_data(f"SELECT * FROM block WHERE id = '{user_id}' LIMIT 1")
                if block is not None:
                    await app.send_message(user_id, "کاربر عزیز شما آنبلاک شدید و اکنون می توانید از ربات استفاده کنید")
                    await app.send_message(Admin, f"کاربر [ {user_id} ] از ربات آنبلاک شد")
                    update_data(f"DELETE FROM block WHERE id = '{user_id}' LIMIT 1")
                else:
                    await app.send_message(Admin, "این کاربر از ربات بلاک نیست!")
            else:
                await app.send_message(Admin, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(Admin, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif text == "افزایش الماس ➕":
        await app.send_message(Admin, "➕ **افزایش الماس کاربر**\n\nآیدی عددی کاربر را ارسال کنید:", reply_markup=AdminBack)
        update_data(f"UPDATE user SET step = 'amountinc' WHERE id = '{Admin}' LIMIT 1")

    elif user["step"] == "amountinc":
        if text.isdigit():
            user_id = int(text.strip())
            if get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1") is not None:
                await app.send_message(Admin, "میزان الماس مورد نظر خود را برای افزایش وارد کنید:")
                update_data(f"UPDATE user SET step = 'amountinc2-{user_id}' WHERE id = '{Admin}' LIMIT 1")
            else:
                await app.send_message(Admin, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(Admin, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif user["step"].split("-")[0] == "amountinc2":
        if text.isdigit():
            user_id = int(user["step"].split("-")[1])
            count = int(text.strip())
            user_amount = get_data(f"SELECT amount FROM user WHERE id = '{user_id}' LIMIT 1")
            user_upamount = int(user_amount["amount"]) + int(count)
            update_data(f"UPDATE user SET amount = '{user_upamount}' WHERE id = '{user_id}' LIMIT 1")
            await app.send_message(Admin, f"مبلغ {count} الماس به حساب کاربر [ {user_id} ] افزوده شد\nموجودی جدید کاربر: {user_upamount} الماس")
            await app.send_message(user_id, f"مبلغ {count} الماس از طرف مدیر به حساب شما افزوده شد\nموجودی جدید شما: {user_upamount} الماس")
            update_data(f"UPDATE user SET step = 'none' WHERE id = '{Admin}' LIMIT 1")
        else:
            await app.send_message(Admin, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif text == "کسر الماس ➖":
        await app.send_message(Admin, "➖ **کسر الماس کاربر**\n\nآیدی عددی کاربر را ارسال کنید:", reply_markup=AdminBack)
        update_data(f"UPDATE user SET step = 'amountdec' WHERE id = '{Admin}' LIMIT 1")

    elif user["step"] == "amountdec":
        if text.isdigit():
            user_id = int(text.strip())
            if get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1") is not None:
                await app.send_message(Admin, "میزان الماس مورد نظر خود را برای کسر وارد کنید:")
                update_data(f"UPDATE user SET step = 'amountdec2-{user_id}' WHERE id = '{Admin}' LIMIT 1")
            else:
                await app.send_message(Admin, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(Admin, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif user["step"].split("-")[0] == "amountdec2":
        if text.isdigit():
            user_id = int(user["step"].split("-")[1])
            count = int(text.strip())
            user_amount = get_data(f"SELECT amount FROM user WHERE id = '{user_id}' LIMIT 1")
            if int(user_amount["amount"]) >= int(count):
                user_upamount = int(user_amount["amount"]) - int(count)
                update_data(f"UPDATE user SET amount = '{user_upamount}' WHERE id = '{user_id}' LIMIT 1")
                await app.send_message(Admin, f"مبلغ {count} الماس از حساب کاربر [ {user_id} ] کسر شد\nموجودی جدید کاربر: {user_upamount} الماس")
                await app.send_message(user_id, f"مبلغ {count} الماس از طرف مدیر از حساب شما کسر شد\nموجودی جدید شما: {user_upamount} الماس")
                update_data(f"UPDATE user SET step = 'none' WHERE id = '{Admin}' LIMIT 1")
            else:
                await app.send_message(Admin, "موجودی کاربر کافی نیست!")
        else:
            await app.send_message(Admin, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif text == "فعال کردن سلف 🔵":
        await app.send_message(Admin, "🔵 **فعال‌سازی سلف کاربر**\n\nآیدی عددی کاربر را ارسال کنید:", reply_markup=AdminBack)
        update_data(f"UPDATE user SET step = 'selfon' WHERE id = '{Admin}' LIMIT 1")

    elif user["step"] == "selfon":
        if text.isdigit():
            user_id = int(text.strip())
            user_info = get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
            if user_info is not None:
                if user_info["self"] == "inactive":
                    if user_info["phone"] is not None:
                        if not os.path.isfile(f"sessions/{user_id}.session-journal"):
                            async with lock:
                                temp_Client[user_id] = {}
                                temp_Client[user_id]["client"] = Client(f"sessions/{user_id}", api_id=API_ID, api_hash=API_HASH, device_model="center-self", system_version="Linux")
                                temp_Client[user_id]["number"] = user_info["phone"]
                                await temp_Client[user_id]["client"].connect()
                            try:
                                await app.send_message(Admin, "در حال پردازش...")
                                async with lock:
                                    temp_Client[user_id]["response"] = await temp_Client[user_id]["client"].send_code(temp_Client[user_id]["number"])
                                await app.send_message(Admin, "کد تایید 5 رقمی را با فرمت زیر ارسال کنید:\n1.2.3.4.5")
                                update_data(f"UPDATE user SET step = 'selfon2-{user_id}' WHERE id = '{Admin}' LIMIT 1")
                            except Exception as e:
                                print(f"Error in selfon: {e}")
                                async with lock:
                                    await temp_Client[user_id]["client"].disconnect()
                                    del temp_Client[user_id]
                                if os.path.isfile(f"sessions/{user_id}.session"):
                                    try:
                                        os.remove(f"sessions/{user_id}.session")
                                    except: pass
                        else:
                            await app.send_message(Admin, "اشتراک سلف برای این کاربر از قبل فعال است!")
                    else:
                        await app.send_message(Admin, "این کاربر شماره تلفن ثبت شده ندارد!")
                else:
                    await app.send_message(Admin, "سلف این کاربر از قبل فعال است!")
            else:
                await app.send_message(Admin, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(Admin, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif text == "غیرفعال کردن سلف 🔴":
        await app.send_message(Admin, "🔴 **غیرفعال کردن سلف کاربر**\n\nآیدی عددی کاربر را ارسال کنید:", reply_markup=AdminBack)
        update_data(f"UPDATE user SET step = 'selfoff' WHERE id = '{Admin}' LIMIT 1")

    elif user["step"] == "selfoff":
        if text.isdigit():
            user_id = int(text.strip())
            user_info = get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
            if user_info is not None:
                if user_info["self"] == "active":
                    await app.send_message(Admin, "**هشدار! با این کار اشتراک کاربر مورد نظر به طور کامل حذف می شود و امکان فعالسازی دوباره از پنل مدیریت وجود ندارد\n\nاگر از این کار اطمینان دارید روی گزینه تایید و در غیر این صورت روی گزینه برگشت کلیک کنید**", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="تایید", callback_data=f"AcceptDelSub-{user_id}")
                            ],
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                            ]
                        ]
                    ))
                    update_data(f"UPDATE user SET step = 'none' WHERE id = '{Admin}' LIMIT 1")
                else:
                    await app.send_message(Admin, "اشتراک سلف برای این کاربر غیرفعال است!")
            else:
                await app.send_message(Admin, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(Admin, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif text == "روشن کردن ربات 🔵":
        if bot["status"] == "OFF":
            update_data("UPDATE bot SET status = 'ON'")
            await app.send_message(Admin, "✅ **ربات روشن شد!**")
        else:
            await app.send_message(Admin, "⚠️ **ربات از قبل روشن است!**")

    elif text == "خاموش کردن ربات 🔴":
        if bot["status"] == "ON":
            update_data("UPDATE bot SET status = 'OFF'")
            await app.send_message(Admin, "🔴 **ربات خاموش شد!**")
        else:
            await app.send_message(Admin, "⚠️ **ربات از قبل خاموش است!**")

    elif text == "صفحه اصلی 🏠":
        await app.send_message(Admin, "🚀 به سلف‌ساز پیشرفته ونوم خوش آمدید ✨\n\n🪐 اینجا می‌توانید دستیار خودتان را داشته باشید و اکانتتان را ۲۴ ساعته آنلاین نگه دارید.\n\n👇جهت ادامه یکی از گزینه‌های زیر را انتخاب کنید:", reply_markup=Main)
        update_data(f"UPDATE user SET step = 'none' WHERE id = '{Admin}' LIMIT 1")
        async with lock:
            if Admin in temp_Client:
                del temp_Client[Admin]
            if Admin in temp_code:
                del temp_code[Admin]

#===================== Start ======================#
print(Fore.GREEN + "Bot is running...")
app.run()